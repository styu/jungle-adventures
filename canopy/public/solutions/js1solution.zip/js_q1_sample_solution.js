$(document).ready(function() {
  alert($('#distraction-sign').text());
});