$(function() {

  // Creates the DOMephant image
  var elephant = document.createElement('img');
  $(elephant).attr('src', 'domephant.png');
  $(elephant).css('position', 'absolute');
  $(elephant).css("left", 0);
  $(elephant).css("top", 0);
  $('body').append(elephant);
  
  /* Your JavaScript Here */
  
});