/* Your JavaScript Here */

/* 
You should write some sort of a POST method to fetch the results from:

http://6.470.scripts.mit.edu/jungleadventures/secret.php

and populate the paragraph tag "<p id="secret-text-goes-here"><p>" with the content
*/